// We know we're using browserify which compiles modules with global exposted
global.React = require('react');
global.ReactDOM = require('react-dom');
global.ReactDOMServer = require('react-dom/server');
